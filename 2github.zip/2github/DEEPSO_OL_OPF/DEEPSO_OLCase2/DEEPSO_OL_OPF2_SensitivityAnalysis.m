%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Wenlei Bai, PhD (email: wenlei_bai@baylor.edu)
% 08/02/2024
%
% Application of Modern Heuristic Optimization Algorithms
% for Solving Optimal Power Flow Problems
%
% Differential Evolutionary Particle Swarm Optimization (DEEPSO) based on OL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SETTING PARAMETERS
global proc;
proc.last_improvement=1;
% function evaluation counter.
proc.i_eval=0;
maxCycle=10; %/*The number of cycles for foraging {a stopping criteria}*/

global ref_bus_coeff nonRefLogicID REF PV PQ mpc Qmax Qmin Pmax Pmin xfmrID capID;
ref_bus_coeff = [];
mpc=loadcase('case_ieee30');
% mpc=loadcase('case118');
nrowBranches = size(mpc.branch(:,1),1);
nrowBuses = size(mpc.bus(:,1),1);
load('ref_30bus_coeff_valve.mat');
% load('ref_118bus_coeff.mat');
% User defined generator bus P and Q limits, instead of obtaining from
% MatPower data:
Qmax = [200;100;80;60;50;60];
Qmin = [-20;-20;-15;-15;-10;-15];
Pmax = [200;80;50;35;30;40];
Pmin = [50 ;20;15;10;10;12];
% Qmax = mpc.gen(:,4);
% Qmin = mpc.gen(:,5);
% Pmax = mpc.gen(:,9);
% Pmin = mpc.gen(:,10);
[REF, PV, PQ] = bustypes(mpc.bus, mpc.gen); % get bus index
branches = linspace(1, nrowBranches, nrowBranches)';
buses = mpc.bus(:,1);
nonRefLogicID = mpc.gen(:,1) ~= REF; %get the logical array of non slack bus
lbP = Pmin(nonRefLogicID)';
ubP = Pmax(nonRefLogicID)';
xfmrID = mpc.branch(:,9) > 0; 
xfmrID = branches(xfmrID); % get transformer branch index
% capID = mpc.bus(:,6) ~= 0;
% capID = buses(capID); % get cap bus index
capID = [10;12;15;17;20;21;23;24;29];

%/* Problem specific variables*/
proc.D=size(PV,1)*2 + size(REF,1) + size(xfmrID,1) + size(capID,1); %/*The number of parameters of the problem to be optimized*/
proc.D_cont = proc.D;

% /*All food sources are initialized */
%/lb, ub = [1, D], Variables are initialized in the range [lb,ub]. If each parameter has different range, use arrays lb[j], ub[j] */
proc.lb=[lbP,unifrnd(0.95,0.95,1,size(PV,1)+1),unifrnd(0.9,0.9,1,size(xfmrID,1)),unifrnd(0,0,1,size(capID,1))];
proc.ub=[ubP,unifrnd(1.10,1.10,1,size(PV,1)+1),unifrnd(1.10,1.10,1,size(xfmrID,1)),unifrnd(5,5,1,size(capID,1))];

% Particles' lower bounds.
Xmin=proc.lb;
% Particles' upper bounds.
Xmax=proc.ub;
OL_P = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INITIALIZE strategic parameters of DEEPSO
global deepso_par;
global ff_par;
% deepso_par.memGBestMaxSize = ceil( proc.pop_size * 0.2 );
deepso_par.mutationRate = 0.5;
% deepso_par.communicationProbability = 0.5;
deepso_par.OLSearchProbability = 0.3;
deepso_par.localSearchContinuousDiscrete = 0;
ff_par.excludeBranchViolations = 0;
ff_par.factor = 1;
ff_par.numCoefFF = 3;
ff_par.avgCoefFF = zeros( 1, ff_par.numCoefFF );
ff_par.coefFF = ones( 1, ff_par.numCoefFF );
ff_par.numFFEval = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
runTime = 1;
globalMins = zeros(runTime,1);
for r = 1: runTime
    tic
    comPs = [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
    popSizes = [10 20 30 40 50 60 70 80 90 100];
    for idx1 = 1:length(comPs)
        comP = comPs(idx1);
        deepso_par.communicationProbability = comP;

        for idx2 = 1:length(popSizes)
            pIdx = popSizes(idx2);
            proc.pop_size=pIdx;
            deepso_par.memGBestMaxSize = ceil( proc.pop_size * 0.2 );
    
            % INITIALIZE generation counter
            iter = 1;
            fitMaxVector = nan(1,maxCycle);
            ITER = nan(1,maxCycle);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % RANDOMLY INITIALIZE CURRENT population
            Vmin = -Xmax + Xmin;
            Vmax = -Vmin;
            pos = zeros( proc.pop_size, proc.D );
            vel = zeros( proc.pop_size, proc.D );
            for i = 1 : proc.pop_size
                pos( i, : ) = Xmin + ( Xmax - Xmin ) .* rand( 1, proc.D );
                vel( i, : ) = Vmin + ( Vmax - Vmin ) .* rand( 1, proc.D );
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % INITIALIZE strategic parameters of DEEPSO
            communicationProbability = deepso_par.communicationProbability;
            mutationRate = deepso_par.mutationRate;
            % Weights matrix
            % 1 - inertia
            % 2 - memory
            % 3 - cooperation
            % 4 - perturbation
            weights = rand( proc.pop_size, 4 );
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            [fit,Power,pf]=Cost_case2(pos, proc.pop_size);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            proc.i_eval = proc.i_eval + proc.pop_size;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % UPDATE GLOBAL BEST
            [ gbestval, gbestid ] = min( fit );
            gbest = pos( gbestid, : );
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Number particles saved in the memory of the DEEPSO
            memGBestMaxSize = deepso_par.memGBestMaxSize;
            memGBestSize = 1;
            % Memory of the DEEPSO
            memGBest = [];
            memGBestFit = [];
            memGBest( memGBestSize, : ) = gbest;
            memGBestFit( 1, memGBestSize ) = gbestval;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            while ( iter <= maxCycle )
            
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % PRINT results
                fprintf( 'iter: %3d\t gBest: %.2f\n', iter, gbestval );
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % COPY CURRENT population
                copyPos = pos;
                copyVel = vel;
                copyWeights = weights;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % UPDATE MEMORY
                tmpMemGBestSize = memGBestSize + proc.pop_size;
                tmpMemGBestFit = cat( 2, memGBestFit, fit' );
                tmpMemGBest = cat( 1, memGBest, pos );
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                if rand() > deepso_par.OLSearchProbability
                    for i = 1 : proc.pop_size
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % DEEPSO movement rule
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % COMPUTE NEW VELOCITY for the particles of the CURRENT population
                        vel( i, : ) = DEEPSO_COMPUTE_NEW_VEL( pos( i, : ), gbest, fit( i ), tmpMemGBestSize, tmpMemGBestFit, tmpMemGBest, vel( i, : ), Vmin, Vmax, weights( i, : ), communicationProbability );
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % COMPUTE NEW POSITION for the particles of the CURRENT population
                        [ pos( i, : ), vel( i, : ) ] = COMPUTE_NEW_POS( pos( i, : ), vel( i, : ) );
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % DEEPSO movement rule
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % MUTATE WEIGHTS of the particles of the COPIED population
                        copyWeights( i, : ) = MUTATE_WEIGHTS( weights( i, : ), mutationRate );
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % COMPUTE NEW VELOCITY for the particles of the COPIED population
                        copyVel( i, : ) = DEEPSO_COMPUTE_NEW_VEL( copyPos( i, : ), gbest, fit( i ), tmpMemGBestSize, tmpMemGBestFit, tmpMemGBest, copyVel( i, : ), Vmin, Vmax, copyWeights( i, : ), communicationProbability );
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % COMPUTE NEW POSITION for the particles of the COPIED population
                        [ copyPos( i, : ), copyVel( i, : ) ] = COMPUTE_NEW_POS( copyPos( i, : ), copyVel( i, : ) );
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ENFORCE search space limits of the COPIED population
                    [ copyPos, copyVel ] = ENFORCE_POS_LIMITS( copyPos, Xmin, Xmax, copyVel, Vmin, Vmax );
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ENFORCE search space limits of the CURRENT population
                    [ pos, vel ] = ENFORCE_POS_LIMITS( pos, Xmin, Xmax, vel, Vmin, Vmax );
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % EVALUATE the COPIED population
                    [copyFit,copyPower,copyPf]=Cost_case2(copyPos,proc.pop_size);
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    proc.i_eval = proc.i_eval + proc.pop_size;
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % EVALUATE the CURRENT population
                    [fit,Power,pf]=Cost_case2(pos,proc.pop_size);
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    proc.i_eval = proc.i_eval + proc.pop_size;
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % CREATE NEW population to replace CURRENT population
                    selParNewSwarm = ( copyFit < fit );
                    for i = 1 : proc.pop_size
                        if selParNewSwarm( i )
                            fit( i ) = copyFit( i );
                            pos( i, : ) = copyPos( i, : );
                            vel( i, : ) = copyVel( i, : );
                            weights( i, : ) = copyWeights( i, : );
                            Power(i,:) = copyPower(i,:);
                            pf(i) = copyPf(i);
                        end
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                else
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % OL Search
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    if rand < OL_P
                        idx = fix(rand*proc.pop_size)+1;
                        for i = 1 : proc.pop_size
                            if i == idx % only perform OL when the number matches to avoild large computational cost                        
                                k = fix(rand*proc.pop_size)+1; 
                                %/*Randomly selected solution must be different from the solution i*/        
                                while(k==i)
                                    k=fix(rand*proc.pop_size)+1;
                                end
                                Ts = pos(k, :) + rand * (pos(gbestid, :)- pos(k, :));
                                Xs = pos(i,:);
            
                                [fitFA, X_predict, X_best] = OL_SEARCH(Ts,Xs);
                                [X_predict, ~ ] = ENFORCE_POS_LIMITS(X_predict, Xmin, Xmax, vel, Vmin, Vmax );
                                
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                [fitPred,powerPred,pfPred]=Cost_case2(X_predict,1);
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                
                                proc.i_eval = proc.i_eval + 1;
                                
                                %update best
                                if fitPred < min(fitFA) %min(ObjVal_FA) is the objective value of X_best
                                    pos(i,:) = X_predict;
                                    fit(i,:) = fitPred;
                                    Power(i,:) = powerPred;
                                    pf(i,:) = pfPred;
                                    gbestid = i;
                                else
                                    [gbestFA, gbestidFA] = min(fitFA);
                                    pos(i,:)= X_best;
                                    fit(i,:)= gbestFA;
                                    gbestid = gbestidFA;
                                end      
                            end     
                        end                    
                    end
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % UPDATE GLOBAL BEST
                [ tmpgbestval, gbestid ] = min( fit );
                if tmpgbestval < gbestval
                    gbestval = tmpgbestval;
                    gbest = pos( gbestid, : );
                    GlobalPower = Power(gbestid,:);
                    GlobalPf = pf(gbestid);
                    % UPDATE MEMORY DEEPSO
                    if memGBestSize < memGBestMaxSize
                        memGBestSize = memGBestSize + 1;
                        memGBest( memGBestSize, : ) = gbest;
                        memGBestFit( 1, memGBestSize ) = gbestval;
                    else
                        [ ~, tmpgworstid ] = max( memGBestFit );
                        memGBest( tmpgworstid, : ) = gbest;
                        memGBestFit( 1, tmpgworstid ) = gbestval;
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
                % RE-CALCULATES NEW COEFFICIENTS for the fitness function
                CALC_COEFS_FF();
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % UPDATE generation counter
                ITER(iter) = iter;
                fitMaxVector(1,iter) = gbestval;
                iter = iter + 1;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end

            globalMins(r) = gbestval;
            finalResults.fitness(idx1,idx2) = globalMins(r);
            finalResults.p_n_matrix{idx1, idx2} = {deepso_par.communicationProbability,proc.pop_size};
            T(r) = toc;
        end
    end
end