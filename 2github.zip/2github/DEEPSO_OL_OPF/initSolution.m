clear all;
clc;
proc.pop_size = 50;
mpc=loadcase('case_ieee30');
nrowBranches = size(mpc.branch(:,1),1);
nrowBuses = size(mpc.bus(:,1),1);
load('ref_30bus_coeff.mat');
% User defined generator bus P and Q limits, instead of obtaining from
% MatPower data:
Qmax = [200;100;80;60;50;60];
Qmin = [-20;-20;-15;-15;-10;-15];
Pmax = [200;80;50;35;30;40];
Pmin = [50 ;20;15;10;10;12];
[REF, PV, PQ] = bustypes(mpc.bus, mpc.gen); % get bus index
branches = linspace(1, nrowBranches, nrowBranches)';
buses = mpc.bus(:,1);
nonRefLogicID = mpc.gen(:,1) ~= REF; %get the logical array of non slack bus
lbP = Pmin(nonRefLogicID)';
ubP = Pmax(nonRefLogicID)';
xfmrID = mpc.branch(:,9) > 0; 
xfmrID = branches(xfmrID); % get transformer branch index
capID = [10;12;15;17;20;21;23;24;29];
D=size(PV,1)*2 + size(REF,1) + size(xfmrID,1) + size(capID,1); %/*The number of parameters of the problem to be optimized*/
Xmin=[lbP,unifrnd(0.95,0.95,1,size(PV,1)+1),unifrnd(0.9,0.9,1,size(xfmrID,1)),unifrnd(0,0,1,size(capID,1))];
Xmax=[ubP,unifrnd(1.10,1.10,1,size(PV,1)+1),unifrnd(1.10,1.10,1,size(xfmrID,1)),unifrnd(5,5,1,size(capID,1))];
Vmin = -Xmax + Xmin;
Vmax = -Vmin;
for i = 1 : proc.pop_size
    rng(i,"twister"); % ensure the same random number
    pos( i, : ) = Xmin + ( Xmax - Xmin ) .* rand( 1, D );
    vel( i, : ) = Vmin + ( Vmax - Vmin ) .* rand( 1, D );
end