x = 10:10:100;
y = 0.1:0.1:1;
h = heatmap(x,y,data);
h.CellLabelFormat = '%.3f';
h.Title = 'L-index';
h.XLabel = 'population';
h.YLabel = 'communication probability';