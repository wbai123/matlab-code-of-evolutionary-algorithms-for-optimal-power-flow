plot(ITER,fitMaxVector,'LineWidth',2);
ylim([780 2000]);
grid;
xlabel('iterations');
ylabel('$/hr');