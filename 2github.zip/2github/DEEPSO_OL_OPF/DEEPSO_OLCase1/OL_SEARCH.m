function [ObjVal_FA, X_predict, X_best] = OL_SEARCH(Ts, Xs)
    % Mix Ts and Xs by making use of Orthognal Learning to construct a candidate solution Vs
    global proc;
    M = 2^ceil(log2(proc.D+1));
    OB = Generate_OA(proc.D);
    for ii = 1: M
        for jj = 1: proc.D
            if OB(ii,jj) == 1
                OB(ii,jj) = Xs(jj);
            else
                OB(ii,jj) = Ts(jj);
            end
        end 
    end
    % Factor Anaysis
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [ObjVal_FA,~,~]=Cost_case1(OB,M);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    BestInd_FA = find(ObjVal_FA==min(ObjVal_FA));
    BestInd_FA = BestInd_FA(end);
    X_best = OB(BestInd_FA,:);
    OA = Generate_OA(proc.D);
    for jj = 1:proc.D
        ind1 = OA(:,jj)==1;
        S1(jj) = sum(ObjVal_FA(ind1))/(M/2);
        ind2 = OA(:,jj)==2;
        S2(jj) = sum(ObjVal_FA(ind2))/(M/2);
        if S1(jj) >= S2(jj)
            X_predict(jj) = S1(jj);
        else
            X_predict(jj) = S2(jj);
        end       
    end
end