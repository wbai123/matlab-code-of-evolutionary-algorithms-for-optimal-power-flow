clear all;
close all;
clc;
load('ITER.mat');
fig = figure;
% ylim([780 2000]);
load('case3_initStart/fitMaxVector_OL.mat');
plot(ITER,fitMaxVector,'-','LineWidth',2);
grid;
hold on;

load('case3_initStart/fitMaxVector_ABC.mat');
plot(ITER,fitMaxVector,'-.','LineWidth',2);
hold on;

load('case3_initStart/fitMaxVector_DE.mat');
plot(ITER,fitMaxVector,':','LineWidth',2);
hold on;

load('case3_initStart/fitMaxVector_PSO.mat');
plot(ITER,fitMaxVector,'--','LineWidth',2);
hold on;


xlabel('iterations','fontsize',12,'fontweight','bold');
ylabel('MW','fontsize',12,'fontweight','bold');
legend('Proposed','ABC','DE','PSO');
magnifyOnFigure(fig);

