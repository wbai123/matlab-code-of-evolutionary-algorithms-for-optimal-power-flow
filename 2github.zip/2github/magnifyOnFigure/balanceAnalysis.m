close all;
clear all;

fig(1) = openfig('OL_BA1.fig');
tmp(1) = get(gca,'Title');

fig(2) = openfig('PSO_BA1.fig');
tmp(2) = get(gca,'Title');

fig(3) = openfig('DE_BA1.fig');
tmp(3) = get(gca,'Title');

fig(4) = openfig('ABC_BA1.fig');
tmp(4) = get(gca,'Title');

fig(5) = openfig('OL_BA2.fig');
tmp(5) = get(gca,'Title');

fig(6) = openfig('PSO_BA2.fig');
tmp(6) = get(gca,'Title');

fig(7) = openfig('DE_BA2.fig');
tmp(7) = get(gca,'Title');
 
fig(8) = openfig('ABC_BA2.fig');
tmp(8) = get(gca,'Title');

fig(9) = openfig('OL_BA3.fig');
tmp(9) = get(gca,'Title');

fig(10) = openfig('PSO_BA3.fig');
tmp(10) = get(gca,'Title');

fig(11) = openfig('DE_BA3.fig');
tmp(11) = get(gca,'Title');
 
fig(12) = openfig('ABC_BA3.fig');
tmp(12) = get(gca,'Title');
 
fig(13) = openfig('OL_BA4.fig');
tmp(13) = get(gca,'Title');

fig(14) = openfig('PSO_BA4.fig');
tmp(14) = get(gca,'Title');

fig(15) = openfig('DE_BA4.fig');
tmp(15) = get(gca,'Title');

fig(16) = openfig('ABC_BA4.fig');
tmp(16) = get(gca,'Title');


for i = 1:16
    hLegend(i) = findobj(fig(i), 'Type', 'Legend');
end

figure;
t = tiledlayout(4,4);
t.TileSpacing = 'compact';
t.Padding = 'none';

for i = 1:16
    nexttile
    h = findobj(fig(i), 'type', 'line');
    plot(h(1).YData, 'LineWidth',1.5, 'Color', 'R', 'LineStyle','--');
    hold on;
    grid on;
    plot(h(2).YData, 'LineWidth',1.5, 'Color', 'B');
    legend(hLegend(i).String);
    title(get(tmp(i),'String'));
end


% nexttile
% h = findobj(fig(1), 'type', 'line');
% plot(h(1).YData, 'LineWidth',1.5, 'Color', 'R', 'LineStyle','--');
% hold on;
% plot(h(2).YData, 'LineWidth',1.5, 'Color', 'B');
% legend(hLegend1.String);
% 
% nexttile
% h = findobj(fig(2), 'type', 'line');
% plot(h(1).YData, 'LineWidth',1.5, 'Color', 'R', 'LineStyle','--');
% hold on;
% plot(h(2).YData, 'LineWidth',1.5, 'Color', 'B');
% 
% 
% nexttile
% h = findobj(fig(3), 'type', 'line');
% plot(h(1).YData, 'LineWidth',1.5, 'Color', 'R', 'LineStyle','--');
% hold on;
% plot(h(2).YData, 'LineWidth',1.5, 'Color', 'B');






