function Cr = rcost(w,wi,wr,kr)
%kp = 1; %penality cost coefficient
% kr =0.01; % reserve cost coefficient
vi = 5; %cut-in wind speed m/s
vr = 15; % rated wind speed m/s
vo = 45; % cut-out wind speed m/s
c = 10;
k = 2;
%wr = 40; % wind turbine rated power MW
L = (vr-vi)./vi; %ratio of linear range of wind speed to cut-in wind speed
rou = w./wr; % ratio of wind power output to rated wind power;
       Cr = kr .*(wi-w).*k.*L.*vi./c.*(((1+rou.*L).*vi)./c).^(k-1).*exp(-(((1+rou.*L).*vi)./c).^k);
end