%cost function: minimize fuel cost
function [FF,Power,pf]=Cost_case2(Swarm,n_par) % size of pp is (n_par by D)
global nonRefLogicID REF PV PQ mpc Qmax Qmin Pmax Pmin xfmrID capID;
NL = size(mpc.branch(:,1),1); % total number of tranmission lines
opt = mpoption('pf.alg','NR','pf.enforce_q_lims',0,'out.all',0,'verbose', 0);
V_bus_max=1.06;
V_bus_min=0.94;

for j=1:n_par
    mpc.gen(nonRefLogicID,2)=Swarm(j,1 : size(PV,1)); % P on PV bus
    mpc.gen(:,6)=Swarm(j,size(PV,1)+1 : 2*size(PV,1) + size(REF,1)); % V on PV bus
    mpc.branch(xfmrID,9)=Swarm(j,2*size(PV,1) + size(REF,1) + 1 : end-size(capID,1)); % XFMR on branches
    mpc.bus(capID,6)=Swarm(j,end-size(capID,1)+1 : end)'; % Shunt on buses
    pf(j) = runpf(mpc,opt);
    Power(j,:)=pf(j).gen(:,2);         
    pen_fac=5000; % penalty factor
    
    hPG1=0;
    if pf(j).gen(~nonRefLogicID,2) < Pmin(~nonRefLogicID)
        hPG1=(Pmin(~nonRefLogicID)-pf(j).gen(~nonRefLogicID,2)).^2;
    elseif pf(j).gen(~nonRefLogicID,2) > Pmax(~nonRefLogicID)
        hPG1=(Pmax(~nonRefLogicID)-pf(j).gen(~nonRefLogicID,2)).^2;
    end
    hPG1_total=hPG1; %slack bus power that surpass its limits

    Qout = pf(j).gen(:,3);
    ubv = Qout > Qmax;
    lbv = Qout < Qmin;
    hQG = 0;
    if sum(ubv) > 0
        hQG = hQG + sum((Qout(ubv)-Qmax(ubv)).^2);
    end
    if sum(lbv) > 0
        hQG = hQG + sum((Qmin(lbv)-Qout(lbv)).^2);
    end 
    hQG_total = hQG; %bus reactive power that surpass their limits
   
    V_bus = pf(j).bus(:,8);
    V_PQ = V_bus(PQ);
    ubv = V_PQ > V_bus_max;
    lbv = V_PQ < V_bus_min;
    hV_PQ = 0;
    if sum(ubv) > 0
        hV_PQ = hV_PQ + sum((V_PQ(ubv)-V_bus_max).^2);
    end
    if sum(lbv) > 0
        hV_PQ = hV_PQ + sum((V_bus_min-V_PQ(lbv)).^2);
    end
    hV_PQ_total=hV_PQ; %total bus voltages that surpass bus votlage limits 
    
    P_loss(j) = 0;  
    for jjj = 1: NL % total number of transmission lines is 41.
        i_ind = pf(j).branch(jjj,1);
        j_ind = pf(j).branch(jjj,2);
        Vi = pf(j).bus(i_ind,8);
        Vj = pf(j).bus(j_ind,8);
        angi = pf(j).bus(i_ind,9)/180*pi;
        angj = pf(j).bus(j_ind,9)/180*pi;
        P_loss(j) = P_loss(j) + (pf(j).branch(jjj,3)/(pf(j).branch(jjj,3)^2+pf(j).branch(jjj,4)^2)) * (Vi^2 + Vj^2 - 2*Vi*Vj*cos(angi - angj)); % real power loss through transmission lines
    end
    
    F(j) = 100*(P_loss(j) + pen_fac*hPG1_total+pen_fac*hQG_total + 100000*pen_fac*hV_PQ_total); %total Line losses in MW (100MWA base)   
end
    FF = F';
end
