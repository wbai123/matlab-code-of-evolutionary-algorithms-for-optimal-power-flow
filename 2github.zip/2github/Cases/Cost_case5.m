%cost function: maximize the SSV of Jacobian matrix to improve voltage stability
function [FF,Power,pf]=Cost_case3(Swarm,n_par)
global nonRefLogicID REF PV PQ mpc Qmax Qmin xfmrID capID;
opt = mpoption('pf.alg','NR','pf.enforce_q_lims',0,'out.all',0,'verbose', 0);
% opt = mpoption('pf.enforce_q_lims',0,'out.all',0,'verbose', 0);


V_bus_max=1.06;
V_bus_min=0.94;

for j=1:n_par
    mpc.gen(nonRefLogicID,2)=Swarm(j,1 : size(PV,1)); % P on PV bus
    mpc.gen(:,6)=Swarm(j,size(PV,1)+1 : 2*size(PV,1) + size(REF,1)); % V on PV bus
    mpc.branch(xfmrID,9)=Swarm(j,2*size(PV,1) + size(REF,1) + 1 : end-size(capID,1)); % XFMR on branches
    mpc.bus(capID,6)=Swarm(j,end-size(capID,1)+1 : end)'; % Shunt on buses
    J = makeJac(mpc);
    pf(j) = runpf(mpc,opt);
    Power(j,:)=pf(j).gen(:,2);         
    pen_fac=5000; % penalty factor
    if pf(j).gen(~nonRefLogicID,2) < 0
        hPG1=(0-pf(j).gen(~nonRefLogicID,2)).^2;
    else
        hPG1=0;
    end
    hPG1_total=sum(hPG1); %generator bus power that surpass their limits
     
    Qout = pf(j).gen(:,3);
    ubv = Qout > Qmax;
    lbv = Qout < Qmin;
    hQG = 0;
    if sum(ubv) > 0
        hQG = hQG + sum((Qout(ubv)-Qmax(ubv)).^2);
    end
    if sum(lbv) > 0
        hQG = hQG + sum((Qmin(lbv)-Qout(lbv)).^2);
    end
    
    hQG_total = hQG; %bus reactive power that surpass their limits

    V_bus = pf(j).bus(:,8);
    V_PQ = V_bus(PQ);

    ubv = V_PQ > V_bus_max;
    lbv = V_PQ < V_bus_min;
    hV_PQ = 0;
    if sum(ubv) > 0
        hV_PQ = hV_PQ + sum((V_PQ(ubv)-V_bus_max).^2);
    end
    if sum(lbv) > 0
        hV_PQ = hV_PQ + sum((V_bus_min-V_PQ(lbv)).^2);
    end
    
    hV_PQ_total=hV_PQ; %total bus voltages that surpass bus votlage limits 
    
    ssv(j) = svds(J,1,'smallest');
    
    F(j) = -1000000*ssv(j) + pen_fac*hPG1_total;
end
    FF = F';
end
