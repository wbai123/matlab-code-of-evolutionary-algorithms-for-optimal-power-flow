%cost function: minimize fuel cost and improve voltage stability
function [FF,Power,pf]=Cost_case_wind(Swarm,n_par,kp,kr)
global ref_bus_coeff nonRefLogicID REF PV PQ mpc Qmax Qmin Pmax Pmin xfmrID capID;
opt = mpoption('pf.alg','NR','pf.enforce_q_lims',0,'out.all',0,'verbose', 0);
% opt = mpoption('pf.enforce_q_lims',0,'out.all',0,'verbose', 0);

wr1 = 80; % rated power of wind turbine 1 80MW
wr2 = 50; % rated power of wind turbine 1 50MW
V_bus_max=1.05;
V_bus_min=0.95;

for j=1:n_par
    mpc.gen(nonRefLogicID,2)=Swarm(j,1 : size(PV,1)); % P on PV bus
    mpc.gen(:,6)=Swarm(j,size(PV,1)+1 : 2*size(PV,1) + size(REF,1)); % V on PV bus
    mpc.branch(xfmrID,9)=Swarm(j,2*size(PV,1) + size(REF,1) + 1 : end-size(capID,1)); % XFMR on branches
    mpc.bus(capID,6)=Swarm(j,end-size(capID,1)+1 : end)'; % Shunt on buses
    pf(j) = runpf(mpc,opt);
    Power(j,:)=pf(j).gen(:,2);         
    pen_fac=5000; % penalty factor
    hPG1=0;
    if pf(j).gen(~nonRefLogicID,2) < Pmin(~nonRefLogicID)
        hPG1=(Pmin(~nonRefLogicID)-pf(j).gen(~nonRefLogicID,2)).^2;
    elseif pf(j).gen(~nonRefLogicID,2) > Pmax(~nonRefLogicID)
        hPG1=(Pmax(~nonRefLogicID)-pf(j).gen(~nonRefLogicID,2)).^2;
    end
    hPG1_total=hPG1; %slack bus power that surpass its limits
    
    Qout = pf(j).gen(:,3);
    ubv = Qout > Qmax;
    lbv = Qout < Qmin;
    hQG = 0;
    if sum(ubv) > 0
        hQG = hQG + sum((Qout(ubv)-Qmax(ubv)).^2);
    end
    if sum(lbv) > 0
        hQG = hQG + sum((Qmin(lbv)-Qout(lbv)).^2);
    end
    
    hQG_total = hQG; %bus reactive power that surpass their limits

    V_bus = pf(j).bus(:,8);
    V_PQ = V_bus(PQ);

    ubv = V_PQ > V_bus_max;
    lbv = V_PQ < V_bus_min;
    hV_PQ = 0;
    if sum(ubv) > 0
        hV_PQ = hV_PQ + sum((V_PQ(ubv)-V_bus_max).^2);
    end
    if sum(lbv) > 0
        hV_PQ = hV_PQ + sum((V_bus_min-V_PQ(lbv)).^2);
    end
    
    hV_PQ_total=hV_PQ; %total bus voltages that surpass bus votlage limits 
    
	FuelCost1=ref_bus_coeff(:,1)+ref_bus_coeff(:,2).*Power(j,1:6)'+ref_bus_coeff(:,3).*Power(j,1:6)'.^2;
	Cost_pen = quad(@(w)pencost(w,Power(j,2),wr1,kp),Power(j,2),wr1) + quad(@(w)pencost(w,Power(j,3),wr2,kp),Power(j,3),wr2); % bus2 and bus5 as wind generation
	Cost_re = quad(@(w)rcost(w,Power(j,2),wr1,kr),0,Power(j,2)) + quad(@(w)rcost(w,Power(j,3),wr2,kr),0,Power(j,3)); % bus2 and bus5 as wind generation

	F(j) = sum(FuelCost1)+pen_fac*hPG1_total+pen_fac*hQG_total+pen_fac*hV_PQ_total...
	  + Cost_pen + Cost_re; %cost function with wind power penalty and reserve cost function
end
    FF = F';
end
