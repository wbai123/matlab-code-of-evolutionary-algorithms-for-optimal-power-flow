%cost function: minimize fuel cost
function [FF,Power,pf]=Cost_case7(Swarm,n_par)
global ref_bus_coeff nonRefLogicID REF PV PQ mpc Qmax Qmin Pmax Pmin xfmrID capID;
opt = mpoption('pf.alg','NR','pf.enforce_q_lims',0,'out.all',0,'verbose', 0);
% opt = mpoption('pf.enforce_q_lims',0,'out.all',0,'verbose', 0);
V_bus_max=1.06;
V_bus_min=0.94;
% only first 2 units have valve effect, the rest units are the same coefficients as normal fuel cost minimization coefficients.
% GP12coff=[150.00 2.00 0.0016 50.00 0.0630;25.00 2.50 0.0100 40.00 0.0980];
% GP3456=[0,1,0.0625000000000000;0,3.25000000000000,0.00834000000000000;0,3,0.0250000000000000;0,3,0.0250000000000000];
% PGmin12=[50;20];
PGmin=[50;20;15;10;10;12];
for j=1:n_par
    mpc.gen(nonRefLogicID,2)=Swarm(j,1 : size(PV,1)); % P on PV bus
    mpc.gen(:,6)=Swarm(j,size(PV,1)+1 : 2*size(PV,1) + size(REF,1)); % V on PV bus
    mpc.branch(xfmrID,9)=Swarm(j,2*size(PV,1) + size(REF,1) + 1 : end-size(capID,1)); % XFMR on branches
    mpc.bus(capID,6)=Swarm(j,end-size(capID,1)+1 : end)'; % Shunt on buses
    pf(j) = runpf(mpc,opt);
    Power(j,:)=pf(j).gen(:,2);         
    pen_fac=5000; % penalty factor
    hPG1=0;
    if pf(j).gen(~nonRefLogicID,2) < Pmin(~nonRefLogicID)
        hPG1=(Pmin(~nonRefLogicID)-pf(j).gen(~nonRefLogicID,2)).^2;
    elseif pf(j).gen(~nonRefLogicID,2) > Pmax(~nonRefLogicID)
        hPG1=(Pmax(~nonRefLogicID)-pf(j).gen(~nonRefLogicID,2)).^2;
    end
    hPG1_total=hPG1; %slack bus power that surpass its limits
    
    Qout = pf(j).gen(:,3);
    ubv = Qout > Qmax;
    lbv = Qout < Qmin;
    hQG = 0;
    if sum(ubv) > 0
        hQG = hQG + sum((Qout(ubv)-Qmax(ubv)).^2);
    end
    if sum(lbv) > 0
        hQG = hQG + sum((Qmin(lbv)-Qout(lbv)).^2);
    end
    
    hQG_total = hQG; %bus reactive power that surpass their limits

    V_bus = pf(j).bus(:,8);
    V_PQ = V_bus(PQ);

    ubv = V_PQ > V_bus_max;
    lbv = V_PQ < V_bus_min;
    hV_PQ = 0;
    if sum(ubv) > 0
        hV_PQ = hV_PQ + sum((V_PQ(ubv)-V_bus_max).^2);
    end
    if sum(lbv) > 0
        hV_PQ = hV_PQ + sum((V_bus_min-V_PQ(lbv)).^2);
    end
    
    hV_PQ_total=hV_PQ; %total bus voltages that surpass bus votlage limits 
        
%     FuelCost1=GP12coff(:,1)+GP12coff(:,2).*Power(j,1:2)'+GP12coff(:,3).*Power(j,1:2)'.^2+abs(GP12coff(:,4).*sin(GP12coff(:,5).*(PGmin12-Power(j,1:2)')));
%     FuelCost2=GP3456(:,1)+GP3456(:,2).*Power(j,3:6)'+GP3456(:,3).*Power(j,3:6)'.^2;
%     FuelCost3=sum(FuelCost1)+sum(FuelCost2);
    FuelCost3=ref_bus_coeff(:,1)+ref_bus_coeff(:,2).*Power(j,:)'+ref_bus_coeff(:,3).*Power(j,:)'.^2+abs(ref_bus_coeff(:,4).*sin(ref_bus_coeff(:,5).*(PGmin-Power(j,:)')));
    F(j) = sum(FuelCost3)+pen_fac*hPG1_total+pen_fac*hQG_total+pen_fac*hV_PQ_total;
end
    FF = F';
end
