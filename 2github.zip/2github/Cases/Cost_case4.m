%cost function: minimize L-index
function [FF,Power,pf]=Cost_case4(Swarm,n_par)
global nonRefLogicID REF PV PQ mpc Qmax Qmin Pmax Pmin xfmrID capID;
opt = mpoption('pf.alg','NR','pf.enforce_q_lims',0,'out.all',0,'verbose', 0);
% opt = mpoption('pf.enforce_q_lims',0,'out.all',0,'verbose', 0);
load('Ybus_PF.mat');
L_ind = [];

V_bus_max=1.05;
V_bus_min=0.95;

for j=1:n_par
    mpc.gen(nonRefLogicID,2)=Swarm(j,1 : size(PV,1)); % P on PV bus
    mpc.gen(:,6)=Swarm(j,size(PV,1)+1 : 2*size(PV,1) + size(REF,1)); % V on PV bus
    mpc.branch(xfmrID,9)=Swarm(j,2*size(PV,1) + size(REF,1) + 1 : end-size(capID,1)); % XFMR on branches
    mpc.bus(capID,6)=Swarm(j,end-size(capID,1)+1 : end)'; % Shunt on buses
    pf(j) = runpf(mpc,opt);
    Power(j,:)=pf(j).gen(:,2);         
    pen_fac=5000; % penalty factor
    hPG1=0;
    if pf(j).gen(~nonRefLogicID,2) < Pmin(~nonRefLogicID)
        hPG1=(Pmin(~nonRefLogicID)-pf(j).gen(~nonRefLogicID,2)).^2;
    elseif pf(j).gen(~nonRefLogicID,2) > Pmax(~nonRefLogicID)
        hPG1=(Pmax(~nonRefLogicID)-pf(j).gen(~nonRefLogicID,2)).^2;
    end
    hPG1_total=hPG1; %slack bus power that surpass its limits
    
    Qout = pf(j).gen(:,3);
    ubv = Qout > Qmax;
    lbv = Qout < Qmin;
    hQG = 0;
    if sum(ubv) > 0
        hQG = hQG + sum((Qout(ubv)-Qmax(ubv)).^2);
    end
    if sum(lbv) > 0
        hQG = hQG + sum((Qmin(lbv)-Qout(lbv)).^2);
    end
    
    hQG_total = hQG; %bus reactive power that surpass their limits

    V_bus = pf(j).bus(:,8);
    V_PQ = V_bus(PQ);

    ubv = V_PQ > V_bus_max;
    lbv = V_PQ < V_bus_min;
    hV_PQ = 0;
    if sum(ubv) > 0
        hV_PQ = hV_PQ + sum((V_PQ(ubv)-V_bus_max).^2);
    end
    if sum(lbv) > 0
        hV_PQ = hV_PQ + sum((V_bus_min-V_PQ(lbv)).^2);
    end
    
    hV_PQ_total=hV_PQ; %total bus voltages that surpass bus votlage limits 
    

    Y_LG = Ybus(7:30,1:6);
    Y_LL = Ybus(7:30,7:30);
    F_LG = -Y_LL\Y_LG; 
    F_LG_mag = abs(F_LG);
    th_F_LG = angle(F_LG);
    V_gen = pf(j).gen(:,6);
    V_gen_ang = pf(j).bus([1 2 5 8 11 13],9);
    V_gen_ang = V_gen_ang*2*pi/360;
    V_load = pf(j).bus([3 4 6 7 9 10 12 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30],8);
    V_load_ang = pf(j).bus([3 4 6 7 9 10 12 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30],9);
    V_load_ang = V_load_ang * 2*pi/360;
    
    for n = 1:24
        F_LG_sum = 0;
       for i = 1:6
           F_LG_sum = F_LG_sum + F_LG_mag(n,i)*V_gen(i)/V_load(n) * exp(j*(th_F_LG(n,i) + V_gen_ang(i) - V_load_ang(n)));         
       end
       L_ind(n) = abs(1-F_LG_sum);
    end
    
    FuelCost1=max(L_ind);
    
    F(j) = FuelCost1 + pen_fac*hPG1_total + pen_fac*hQG_total + 100000*pen_fac*hV_PQ_total; %total conventional thermal cost
end
    FF = F';
end
