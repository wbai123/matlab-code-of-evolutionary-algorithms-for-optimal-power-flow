%reference: Intelligent evolutionary algorithms for large parameter optimization problems
function OA = Generate_OA(N)

n = 2^ceil(log2(N+1));
    for i = 1: n
       for j = 1: N
           level = 0;
           k = j;
           mask = n/2;
           while k>0
               if mod(k,2) & (bitand(i-1,mask)~=0)
                   level = mod(level + 1, 2);
               end
               k = floor(k/2);
               mask = mask/2;
               OA(i,j) = level + 1;
           end
       end
    end
end


% clear all;
% 
% clc;
% D = 11;
% M = 2^ceil(log2(D+1));
% N = M - 1;
% u = log2(M);
% for a = 1: M
%     for k = 1: u
%         b = 2^(k-1);
%         OA(a,b) = floor(mod((a-1)/2^(u-k),2));
%         
%     end
%     for k = 2:u
%         b = 2^(k-1);
%         for s = 1:b-1
%             OA(a,b+s)= mod(OA(a,s)+OA(a,b),2);
%         end
%     end
% end
% 
% for a = 1:M
%     for b = 1:N
%        if OA(a,b) == 0
%            OA(a,b) = 1;
%        elseif OA(a,b) == 1
%            OA(a,b) = 2;
%        end
%     end
% end
% % 
%  OA = OA(:,1:D)