function [ new_pos ] = LOCAL_SEARCH( pos, Xmin, Xmax )
% Mutates the integer part of the particle
global proc
global deepso_par
new_pos = pos;
        prob = deepso_par.localSearchContinuousDiscrete;
        if rand() > prob
            prob = 1 / proc.D_cont;
            for i = 1 : proc.D_cont
                tmpDim = i;
                if rand() < prob
                    new_pos( tmpDim ) = LOCAL_SEARCH_CONTINUOUS( new_pos( tmpDim ), Xmin( tmpDim ), Xmax( tmpDim ) );
                end
            end
%         else
%             prob = 1 / proc.D_disc;
%             for i = 1 : proc.D_disc;
%                 tmpDim = proc.D_cont + i;
%                 if rand() < prob
%                     new_pos( tmpDim ) = LOCAL_SEARCH_DISCRETE( new_pos( tmpDim ), Xmin( tmpDim ), Xmax( tmpDim ) );
%                 end
%             end
        end
end